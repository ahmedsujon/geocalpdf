<?php

namespace App\Http\Livewire\Auth;

use Livewire\Component;

class AuthBase extends Component
{
    public function render()
    {
        return view('livewire.auth.auth-base');
    }
}
