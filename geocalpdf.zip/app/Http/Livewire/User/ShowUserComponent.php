<?php

namespace App\Http\Livewire\User;

use Livewire\Component;

class ShowUserComponent extends Component
{
    public function render()
    {
        return view('livewire.user.show-user-component');
    }
}
